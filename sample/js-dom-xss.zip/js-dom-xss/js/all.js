

// 可以信任的資料
var farms = [];

document.createElement('li');

document.getElementById('send').onclick = function(){
  var str = document.getElementById('content').value;
   
  document.getElementById('main').innerHTML = str;
}