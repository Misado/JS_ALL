var myMonth = 5;
var thisMonth = 12;
var birthdayCheck = myMonth == thisMonth;
document.getElementById('birthdayId').textContent = birthdayCheck;

var nowPeple = 1;
var totalPeople = 2;
var allPeopleNoHereCheck = totalPeople !== nowPeple;
console.log(allPeopleNoHereCheck);
document.getElementById('peopleId').textContent = allPeopleNoHereCheck;
