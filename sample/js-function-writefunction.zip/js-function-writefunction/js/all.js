function greet(){
    console.log('Hello');
    console.log('請問您想要點什麼？')
}

greet();


