// var cornField = [5,6,8];
var cornField = [];
cornField.push(5);
cornField.push(8);
cornField.push(6);
cornField[0] = 10;
cornField[3] = 100;


console.log('我總共有'+cornField.length+'個玉米田');

console.log(cornField);


