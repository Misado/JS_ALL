var polite = "Hello ";
var indexName =  "洧杰";
var totalPolite = polite + indexName ;

document.getElementById('myName').textContent = totalPolite;
