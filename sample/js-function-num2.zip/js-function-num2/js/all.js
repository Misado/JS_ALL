document.getElementById('countId').onclick = function(){
    var hamNum = document.getElementById('hamNumId').type;
    var cokeNum = document.getElementById('cokeNumId').value;
    alert(hamNum);
    alert(cokeNum);
}